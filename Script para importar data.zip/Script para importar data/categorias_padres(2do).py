import odoorpc

odoo_13 = odoorpc.ODOO('148.113.175.159', port=8069)
odoo_13.login('odoo13_prd_chakao', 'Anderson Rodriguez', '*gA241ghk*')
print('conectado a odoo 13')

odoo_17 = odoorpc.ODOO('localhost', port=8070)
odoo_17.login('qa.grupochakao2024-02-21', 'ajrodriguez@grupochakao.com', '123456')
print('conectado a odoo 17')

#consultar el modelo product.category en odoo 13
category_ids = odoo_17.env['product.category'].search([])
category_ids = odoo_17.env['product.category'].browse(category_ids)
print('cantidad de categorias en odoo 17: ', len(category_ids))

categoria_padre = []
categoria_hija = []

for c in category_ids:
    if c['aux_parent_id'] != False:
        categoria_hija.append({'id':c.id, 'parent_id':c['aux_parent_id']})
    else:
        categoria_padre.append({'id':c.id, 'name':c['aux_id']})

arreglo = []
for h in categoria_hija:
    for p in categoria_padre:
        if h['parent_id'] == p['name']:
            arreglo.append({
                'id':h['id'],
                'parent_id': p['id'] 
                })

for a in arreglo:
    #incluir en odoo 17
    try:
        reg = odoo_17.env['product.category'].browse(a['id'])
        reg.write({'parent_id': a['parent_id']})
        print(f'editado {reg.name}')
    except Exception as e:
        print('error: ', e)
    