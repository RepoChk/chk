import odoorpc

odoo_13 = odoorpc.ODOO('148.113.175.159', port=8069)
odoo_13.login('odoo13_prd_chakao', 'Anderson Rodriguez', '*gA241ghk*')
print('conectado a odoo 13')

odoo_17 = odoorpc.ODOO('localhost', port=8070)
odoo_17.login('qa.grupochakao2024-02-21', 'ajrodriguez@grupochakao.com', '123456')
print('conectado a odoo 17')

#consultar el modelo product.category en odoo 13
category_ids = odoo_13.env['product.category'].search([('name', 'not in', ['Expenses','Saleable','All'])])
print('cantidad de categorias en odoo 13: ', len(category_ids))

#ordena la lista de category_ids
category_ids = sorted(category_ids)

account_ids = odoo_17.env['account.account'].search([])
account_ids = odoo_17.env['account.account'].browse(account_ids)


account_map = []

for a in account_ids:
    account_map.append({
        'code': a.code,
        'id': a.id
    })

i = -1
#crear un ciclo para buscar cada category en odoo 13 e incluir en odoo 17
for category in category_ids:
    i += 1
    if i >= 0:
        category_data = odoo_13.env['product.category'].read(category, ['id','name', 'parent_id','property_account_creditor_price_difference_categ','property_account_income_categ_id','property_account_expense_categ_id','property_stock_account_input_categ_id','property_stock_account_output_categ_id','property_stock_valuation_account_id','property_stock_journal','property_cost_method'])
        category_data = category_data[0]
        # print('category_data: ', category_data)

        property_account_creditor_price_difference_categ = False
        if category_data['property_account_creditor_price_difference_categ']:
            for a in account_map:
                if a['code'] == category_data['property_account_creditor_price_difference_categ'][1].split(' ')[0].rstrip():
                    property_account_creditor_price_difference_categ = a['id']
                    break

        property_account_income_categ_id = False
        if category_data['property_account_income_categ_id']:
            for a in account_map:
                if a['code'] == category_data['property_account_income_categ_id'][1].split(' ')[0].rstrip():
                    property_account_income_categ_id = a['id']
                    break

        property_account_expense_categ_id = False
        if category_data['property_account_expense_categ_id']:
            for a in account_map:
                if a['code'] == category_data['property_account_expense_categ_id'][1].split(' ')[0].rstrip():
                    property_account_expense_categ_id = a['id']
                    break

        property_stock_account_input_categ_id = False
        if category_data['property_stock_account_input_categ_id']:
            for a in account_map:
                if a['code'] == category_data['property_stock_account_input_categ_id'][1].split(' ')[0].rstrip():
                    property_stock_account_input_categ_id = a['id']
                    break

        property_stock_account_output_categ_id = False
        if category_data['property_stock_account_output_categ_id']:
            for a in account_map:
                if a['code'] == category_data['property_stock_account_output_categ_id'][1].split(' ')[0].rstrip():
                    property_stock_account_output_categ_id = a['id']
                    break

        property_stock_valuation_account_id = False
        if category_data['property_stock_valuation_account_id']:
            for a in account_map:
                if a['code'] == category_data['property_stock_valuation_account_id'][1].split(' ')[0].rstrip():
                    property_stock_valuation_account_id = a['id']
                    break

        data_to_create = {
            'name': category_data['name'],
            'property_account_creditor_price_difference_categ': property_account_creditor_price_difference_categ,
            'property_account_income_categ_id': property_account_income_categ_id,
            'property_account_expense_categ_id': property_account_expense_categ_id,
            'property_stock_account_input_categ_id': property_stock_account_input_categ_id,
            'property_stock_account_output_categ_id': property_stock_account_output_categ_id,
            'property_stock_valuation_account_id': property_stock_valuation_account_id,
            'property_stock_journal': 8,
            'aux_id': category_data['id'],
            'aux_parent_id': category_data['parent_id'][0] if category_data['parent_id'] else False,
            'property_cost_method': category_data['property_cost_method'],
        }
        print('creando: ', data_to_create)
        #incluir en odoo 17
        try:
            odoo_17.env['product.category'].create(data_to_create)
        except Exception as e:
            print('error: ', e)
        print('creado: ', category_data['name'])
        print('i=',i)