import odoorpc

odoo_13 = odoorpc.ODOO('148.113.175.159', port=8069)
odoo_13.login('odoo13_prd_chakao', 'Anderson Rodriguez', '*gA241ghk*')
print('conectado a odoo 13')

odoo_17 = odoorpc.ODOO('localhost', port=8070)
odoo_17.login('qa.grupochakao2024-02-21', 'ajrodriguez@grupochakao.com', '123456')
print('conectado a odoo 17')

#consultar el modelo product.template en odoo 13
# product_tmpl_ids = odoo_13.env['product.template'].search([('is_variant', '=', True)])
product_tmpl_ids = odoo_13.env['product.template'].search([])
print('cantidad de product_template en odoo 13: ', len(product_tmpl_ids))

#consultar el modelo product.product en odoo 13
product_product_ids = odoo_13.env['product.product'].search([('product_tmpl_id', 'in', product_tmpl_ids)])
print('cantidad de product_product en odoo 13: ', len(product_product_ids))

#consultar el modelo stock.move en odoo 13
move_product_ids = odoo_13.env['stock.move'].search([('product_id', 'in', product_product_ids)])
print('cantidad de stock_move en odoo 13: ', len(move_product_ids))

c = 0
product_tmpl_ids = []
for m in move_product_ids:
    c += 1
    move = odoo_13.env['stock.move'].read(m, ['product_id'])
    move = move[0]
    product_tmpl_ids.append(move['product_id'][0])
    print(f"{c}) Formateado: {move['product_id'][0]}")

# print('total de product_template despues de verificar movimientos en odoo 13: ', len(product_tmpl_ids))


#consultar el modelo product.category en odoo 17
category_ids = odoo_17.env['product.category'].search([])
category_ids = odoo_17.env['product.category'].browse(category_ids)
print('cantidad de categorias en odoo 17: ', len(category_ids))

#ordena la lista de product_tmpl_ids
product_tmpl_ids = sorted(product_tmpl_ids)

i = -1
#crear un ciclo para buscar cada product en odoo 13 e incluir en odoo 17
for product in product_tmpl_ids:
    i += 1
    if i >= 0:
        product_data = odoo_13.env['product.template'].read(product, ['name', 'display_name', 'default_code','description','barcode','categ_id','list_price','list_price_usd','standard_price','cost_price_usd','is_battery','product_variant_ids'])
        product_data = product_data[0]
        print(product_data)

        categ_id = False
        if product_data['categ_id']:
            for c in category_ids:
                if c.aux_id == product_data['categ_id'][0]:
                    categ_id = c.id
                    break

        # if product_data['product_variant_ids'][0] in 

        data_to_create = {
            'name': product_data['name'],
            'display_name': product_data['display_name'],
            'default_code': product_data['default_code'],
            'description': product_data['description'],
            'barcode': product_data['barcode'],
            'categ_id': categ_id,
            'list_price': product_data['list_price'],
            'list_price_usd': product_data['list_price_usd'],
            'standard_price': product_data['standard_price'],
            'standard_price_usd': product_data['cost_price_usd'],
            # 'is_battery': product_data['is_battery'],
        }
        print('creando: ', data_to_create)
        # incluir en odoo 17
        try:
            odoo_17.env['product.template'].create(data_to_create)
        except Exception as e:
            print('error: ', e)
        print('creado: ', product_data['name'])
        print('i=',i)