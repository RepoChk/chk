import odoorpc

odoo_13 = odoorpc.ODOO('148.113.175.159', port=8069)
odoo_13.login('odoo13_prd_chakao', 'Anderson Rodriguez', '*gA241ghk*')
print('conectado a odoo 13')

odoo_17 = odoorpc.ODOO('localhost', port=8070)
odoo_17.login('grupochakao_qa', 'ajrodriguez@grupochakao.com', '123456')
print('conectado a odoo 17')

#consultar el modelo product.category en odoo 17
price_list_ids = odoo_13.env['product.pricelist.item'].search([])
price_list_ids = odoo_13.env['product.pricelist.item'].browse(price_list_ids)
print('cantidad de categorias en odoo 13: ', len(price_list_ids))

#ordena la lista de price_list_ids
price_list_ids = sorted(price_list_ids)

i = -1
#crear un ciclo para buscar cada product en odoo 13 e incluir en odoo 17
for price in price_list_ids:
    i += 1
    if i >= 0:
        price_data = odoo_13.env['product.pricelist.item'].read(price, ['name', 'display_name', 'default_code','description','barcode','categ_id','list_price','list_price_usd','standard_price','cost_price_usd','is_battery'])
        price_data = price_data[0]

        categ_id = False
        if price_data['categ_id']:
            for c in price_list_ids:
                if c.aux_id == price_data['categ_id'][0]:
                    categ_id = c.id
                    break

        data_to_create = {
            'name': price_data['name'],
            'display_name': price_data['display_name'],
            'default_code': price_data['default_code'],
            'description': price_data['description'],
            'barcode': price_data['barcode'],
            'categ_id': categ_id,
            'list_price': price_data['list_price'],
            'list_price_usd': price_data['list_price_usd'],
            'standard_price': price_data['standard_price'],
            'standard_price_usd': price_data['cost_price_usd'],
            # 'is_battery': price_data['is_battery'],
        }
        print('creando: ', data_to_create)
        #incluir en odoo 17
        # try:
        #     odoo_17.env['product.pricelist.item'].create(data_to_create)
        # except Exception as e:
        #     print('error: ', e)
        # print('creado: ', price_data['name'])
        # print('i=',i)